import  React,{useState} from 'react';
import { Text, View, StyleSheet,Button,TextInput } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  const [name,setName]=useState('murat');
 const [person,setPerson]=useState({name:'selim',age:1})
 
 const [surname, setSurname]=useState('cetin');
 const [age2 ,setAge2]=useState('37')

const changeName=()=>{
  setName('kaan');
  setPerson({name:'murat',age:7})
}

  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        hello word
      </Text>
      <Text>hello mr {name}</Text>
      <Text style={styles.footer}>come on guys </Text>
      <View style={styles.buttonContainer}>

     
      <Text>child name is {person.name} age is {person.age}</Text>
      <Button title='change name' onPress={changeName}/>
      </View>

<View  STYLE>
<Text >enter below surname</Text>
 <TextInput  multiline 
 
 style={styles.input} placeholder='e.g. my name' onChangeText={(val)=>setSurname(val)}/>
 <Text >enter below age</Text>
 <TextInput keyboardType='numeric' style={styles.input} placeholder='e.g. my age' onChangeText={(val)=>setAge2(val)}/>
<Button title='enter surname'/>
 <Text>hello mr {surname} your age is {age2}</Text>


</View>

    </View>
   
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color:"#f00"
  },
  footer:{color:'#00f',fontSize:40
  },buttonContainer:{
    innerWidth:20,
    marginTop:20,
    padding:10

  },
  input:{
borderWidth:1,
padding:2,
margin:8,
width:180,
borderColor:"#00f",



  }
  
});
